# Rocambolli

![Rocambolli The Game](cover_gif.gif)

This is my first platformer. An entry to Ludum-Dare 37.

[You can play here on itch.io.](https://eri0o.itch.io/rocambolli)

I am using my codes below:

 - **[png-font](https://github.com/ericoporto/png-font) :** for pixel font drawing.

 - **[color.js](https://github.com/ericoporto/TouchyEngine/blob/master/color.js) :** tiny 1.47kb js for color normalization.

 I am also using Howler for sound:

  - **[howler.js](https://github.com/goldfire/howler.js) :** a lib for making audio on webpages easier.
